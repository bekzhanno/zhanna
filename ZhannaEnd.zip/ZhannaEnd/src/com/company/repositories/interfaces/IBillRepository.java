package com.company.repositories.interfaces;

import com.company.entities.Bill;

public interface IBillRepository {
    boolean addBill(Bill bill);


}
